<?
$MESS["CT_BCS_TPL_ELEMENT_DELETE_CONFIRM"] = "Буде видалена вся інформація, пов'язана з цим записом. Продовжити?";
$MESS["CT_BCS_TPL_MESS_BTN_BUY"] = "Купити";
$MESS["CT_BCS_TPL_MESS_BTN_ADD_TO_BASKET"] = "До кошику";
$MESS["CT_BCS_TPL_MESS_PRODUCT_NOT_AVAILABLE"] = "Товар наявності";
$MESS["CT_BCS_TPL_MESS_BTN_DETAIL"] = "Детальніше";
$MESS["CT_BCS_TPL_MESS_BTN_SUBSCRIBE"] = "Підписатися";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_BASKET_REDIRECT"] = "Перейти до кошику";
$MESS["ADD_TO_BASKET_OK"] = "Товар доданий до кошику";
$MESS["CT_BCS_TPL_MESS_BTN_COMPARE"] = "Порівняти";
$MESS["CT_BCS_CATALOG_TITLE_ERROR"] = "Помилка";
$MESS["CT_BCS_CATALOG_TITLE_BASKET_PROPS"] = "Властивості товару, що додаються в кошик";
$MESS["CT_BCS_CATALOG_BASKET_UNKNOWN_ERROR"] = "Невідома помилка при додаванні товару в кошик";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_SEND_PROPS"] = "Вибрати";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_CLOSE"] = "Закрити";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_CLOSE_POPUP"] = "Продовжити покупки";
$MESS["CT_BCS_CATALOG_MESS_COMPARE_OK"] = "Товар доданий в список порівняння";
$MESS["CT_BCS_CATALOG_MESS_COMPARE_TITLE"] = "Порівняння товарів";
$MESS["CT_BCS_CATALOG_MESS_COMPARE_UNKNOWN_ERROR"] = "При додаванні товару в список порівняння сталася помилка";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_COMPARE_REDIRECT"] = "Перейти до списку порівняння";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_LAZY_LOAD_WAITER"] = "Завантаження";
$MESS["CT_BCS_CATALOG_PRICE_TOTAL_PREFIX"] = "на суму";
$MESS["CT_BCS_CATALOG_SHOW_MAX_QUANTITY"] = "Наявність";
$MESS["CT_BCS_CATALOG_RELATIVE_QUANTITY_MANY"] = "багато";
$MESS["CT_BCS_CATALOG_RELATIVE_QUANTITY_FEW"] = "мало";
$MESS["CT_BCS_CATALOG_MESS_BTN_LAZY_LOAD"] = "Показати ще";
?>