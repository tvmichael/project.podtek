<?
 $MESS['SPOL_PSEUDO_CANCELLED_COLOR'] = "Цвет отменённых заказов";
 $MESS['SPOL_STATUS_COLOR'] = "Цвет статуса";
 $MESS['SPOL_STATUS_COLOR_GREEN'] = "Зелёный";
 $MESS['SPOL_STATUS_COLOR_GRAY'] = "Серый";
 $MESS['SPOL_STATUS_COLOR_YELLOW'] = "Жёлтый";
 $MESS['SPOL_STATUS_COLOR_RED'] = "Красный";
 ?>