<?
$MESS["CT_BCSE_NOT_FOUND"] = "Leider wurden keine Ergebnisse auf Ihre Suchanfrage gefunden.";
?>