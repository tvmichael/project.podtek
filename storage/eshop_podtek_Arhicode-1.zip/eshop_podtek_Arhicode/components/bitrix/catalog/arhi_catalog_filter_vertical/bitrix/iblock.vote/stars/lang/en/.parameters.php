<?
$MESS ['TP_CBIV_DISPLAY_AS_RATING'] = "Show in rating ";
$MESS ['TP_CBIV_AVERAGE'] = "Average value";
$MESS ['TP_CBIV_RATING'] = "Rating value";
?>