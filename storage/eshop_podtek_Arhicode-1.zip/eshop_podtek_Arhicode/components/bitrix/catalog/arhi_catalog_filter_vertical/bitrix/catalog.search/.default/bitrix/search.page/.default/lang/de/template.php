<?
$MESS["SEARCH_GO"] = "Suchen";
$MESS["CT_BSP_ADDITIONAL_PARAMS"] = "Zusätzliche Suchparameter";
$MESS["CT_BSP_KEYBOARD_WARNING"] = "Die Sprache der Suchanfrage wurde für die \"#query#\" gewechselt";
?>