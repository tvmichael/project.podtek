<?
$MESS["SPS_CHAIN_MAIN"] = "My account";
$MESS["SPS_CHAIN_ORDERS"] = "My orders";
$MESS["SPS_CHAIN_ORDER_DETAIL"] = "Cancel order ##ID#";
?>