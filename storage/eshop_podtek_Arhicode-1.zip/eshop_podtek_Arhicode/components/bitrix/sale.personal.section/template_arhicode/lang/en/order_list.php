<?
$MESS["SPS_CHAIN_MAIN"] = "My account";
$MESS["SPS_CHAIN_ORDERS"] = "My orders";
?>