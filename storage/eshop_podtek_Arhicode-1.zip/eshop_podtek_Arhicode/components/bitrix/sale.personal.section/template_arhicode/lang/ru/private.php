<?php
$MESS["SPS_CHAIN_MAIN"] = "Мой кабинет";
$MESS["SPS_CHAIN_PRIVATE"] = "Персональные данные";
$MESS["SPS_TITLE_PRIVATE"] = "Персональные данные";