<?
$MESS["SPS_CHAIN_MAIN"] = "My account";
$MESS["SPS_CHAIN_PRIVATE"] = "Personal information";
$MESS["SPS_TITLE_PRIVATE"] = "Personal information";
?>