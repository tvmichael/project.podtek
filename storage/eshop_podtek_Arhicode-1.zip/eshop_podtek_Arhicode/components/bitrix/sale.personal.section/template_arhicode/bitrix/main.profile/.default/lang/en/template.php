<?
$MESS["PROFILE_DATA_SAVED"] = "All changes saved";
$MESS["LAST_UPDATE"] = "Last update:";
$MESS["ACTIVE"] = "Active:";
$MESS["NAME"] = "Name:";
$MESS["LAST_NAME"] = "Last name:";
$MESS["SECOND_NAME"] = "Middle name:";
$MESS["EMAIL"] = "E-mail:";
$MESS['MAIN_RESET'] = "Cancel";
$MESS["LOGIN"] = "Login (min. 3 characters):";
$MESS["NEW_PASSWORD"] = "New password (min. 6 characters):";
$MESS["NEW_PASSWORD_CONFIRM"] = "Confirm new password:";
$MESS["SAVE"] = "Save changes";
$MESS["RESET"] = "Reset";
$MESS["LAST_LOGIN"] = "Last authorized:";
$MESS["NEW_PASSWORD_REQ"] = "New Password:";
