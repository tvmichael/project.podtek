<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

global $APPLICATION;

// phone mast
$APPLICATION->AddHeadScript(SITE_TEMPLATE_PATH.'/js/jquery.maskedinput.min.js');
$APPLICATION->AddHeadScript(SITE_TEMPLATE_PATH.'/js/timer.js');