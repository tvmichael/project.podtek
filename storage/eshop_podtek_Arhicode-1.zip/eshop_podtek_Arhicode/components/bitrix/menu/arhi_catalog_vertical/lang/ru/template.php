<?
$MESS["RSGOPRO_CATALOG"] = "Каталог товаров";
$MESS["RSGOPRO_MORE"] = "&#149;&#149;&#149;";
