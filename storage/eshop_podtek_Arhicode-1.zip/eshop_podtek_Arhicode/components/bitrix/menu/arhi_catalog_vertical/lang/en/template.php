<?
$MESS["RSGOPRO_CATALOG"] = "Catalogue";
$MESS["RSGOPRO_MORE"] = "&#149;&#149;&#149;";
?>