<?
$MESS["RSGOPRO_CATALOG_PATH"] = "Путь к корневой директории каталога";
$MESS["RSGOPRO_MAX_ITEM"] = "Количество отображаемых пунктов";
$MESS["RSGOPRO_IS_MAIN"] = "Это главная страница";
$MESS["RSGOPRO_PROPCODE_ELEMENT_IN_MENU"] = "Символьный код свойства для поиска товара в меню";
