<?
$MESS["NAME"] = "Name";
$MESS["LAST_NAME"] = "Nachname";
$MESS["SECOND_NAME"] = "Andere Namen";
$MESS["NEW_PASSWORD_CONFIRM"] = "Passwortbestдtigung";
$MESS["NEW_PASSWORD_REQ"] = "Neues Passwort";
$MESS["MAIN_SAVE"] = "Profileinstellungen speichern";
$MESS["MAIN_PSWD"] = "Passwort";
$MESS["PROFILE_DATA_SAVED"] = "Alle Дnderungen wurden gespeichert";
$MESS["LEGEND_PROFILE"] = "Persцnliche Informationen";
?>