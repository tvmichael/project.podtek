<?
$MESS["NAME"] = "Ім'я";
$MESS["LAST_NAME"] = "Прізвище";
$MESS["SECOND_NAME"] = "По батькові";
$MESS["NEW_PASSWORD_CONFIRM"] = "Підтвердження пароля";
$MESS["NEW_PASSWORD_REQ"] = "Новий пароль";
$MESS["MAIN_SAVE"] = "Зберегти налаштування профілю";
$MESS["MAIN_PSWD"] = "Пароль";
$MESS["PROFILE_DATA_SAVED"] = "Зміни збережені";
$MESS["LEGEND_PROFILE"] = "Особисті дані";
?>