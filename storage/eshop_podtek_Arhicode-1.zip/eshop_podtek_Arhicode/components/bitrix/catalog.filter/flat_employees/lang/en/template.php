<?
$MESS["CT_BCF_FILTER_TITLE"] = "Filter";
$MESS["CT_BCF_SET_FILTER"] = "Show";
$MESS["CT_BCF_DEL_FILTER"] = "Reset";
$MESS["CT_BCF_FROM"] = "from";
$MESS["CT_BCF_TO"] = "to";
?>