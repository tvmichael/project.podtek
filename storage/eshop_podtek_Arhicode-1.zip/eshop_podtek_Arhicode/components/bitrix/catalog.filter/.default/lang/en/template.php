<?
$MESS ['IBLOCK_FILTER_TITLE'] = "Filter";
$MESS ['IBLOCK_SET_FILTER'] = "Filter";
$MESS ['IBLOCK_DEL_FILTER'] = "Reset";
?>