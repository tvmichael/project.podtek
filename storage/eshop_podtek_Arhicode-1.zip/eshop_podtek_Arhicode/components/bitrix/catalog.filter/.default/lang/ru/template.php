<?
$MESS ['IBLOCK_FILTER_TITLE'] = "Фильтр";
$MESS ['IBLOCK_SET_FILTER'] = "Фильтр";
$MESS ['IBLOCK_DEL_FILTER'] = "Сбросить";
?>