<?
$MESS ['PATH_TO_LIST_TIP'] = "The address of the orders page.";
$MESS ['PATH_TO_CANCEL_TIP'] = "The path to the order cancelation page.";
$MESS ['PATH_TO_PAYMENT_TIP'] = "The path to the payment system processor.";
$MESS ['SET_TITLE_TIP'] = "Check this option to set the page title to \"My Order #order_ID#\". ";
$MESS ['ID_TIP'] = "The order ID that will be used to build links to an order view page etc.";
?>