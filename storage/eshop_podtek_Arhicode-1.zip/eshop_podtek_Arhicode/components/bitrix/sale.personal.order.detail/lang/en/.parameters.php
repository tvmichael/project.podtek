<?
$MESS["SPOD_DISALLOW_CANCEL"] = "Don't allow order cancellation";
$MESS["SPOD_DESC_YES"] = "Yes";
$MESS["SPOD_DESC_NO"] = "No";
$MESS["SPOD_PATH_TO_LIST"] = "Orders List page";
$MESS["SPOD_PATH_TO_CANCEL"] = "Order Cancellation page";
$MESS["SPOD_PATH_TO_PAYMENT"] = "Payment system integration page";
$MESS["SPOD_ID"] = "Order ID";
$MESS["SPOD_PROPS_NOT_SHOW"] = "Hide Properties for Payer Type";
$MESS["SPOD_SHOW_ALL"] = "(show all)";
$MESS["SPOD_ACTIVE_DATE_FORMAT"] = "Date format";
$MESS["SPOD_CACHE_GROUPS"] = "Respect access permission";
$MESS["SPOD_PARAM_PREVIEW_PICTURE_WIDTH"] = "Maximum thumbnail image width, px";
$MESS["SPOD_PARAM_PREVIEW_PICTURE_HEIGHT"] = "Maximum thumbnail image height, px";
$MESS["SPOD_PARAM_DETAIL_PICTURE_WIDTH"] = "Maximum detailed image width, px";
$MESS["SPOD_PARAM_DETAIL_PICTURE_HEIGHT"] = "Maximum detailed image height, px";
$MESS["SPOD_PARAM_CUSTOM_SELECT_PROPS"] = "Extra information block properties";
$MESS["SPOD_PARAM_RESAMPLE_TYPE"] = "Image scaling";
$MESS["SPOD_PARAM_RESAMPLE_TYPE_BX_RESIZE_IMAGE_EXACT"] = "Crop";
$MESS["SPOD_PARAM_RESAMPLE_TYPE_BX_RESIZE_IMAGE_PROPORTIONAL"] = "Constrain proportions";
$MESS["SPOD_PARAM_RESAMPLE_TYPE_BX_RESIZE_IMAGE_PROPORTIONAL_ALT"] = "Constrain proportions, improved quality";
$MESS["SPOD_PATH_TO_COPY"] = "Repeat Order page";
$MESS["SPOD_ALLOW_INNER"] = "Enable payment using internal account";
$MESS["SPOD_ONLY_INNER_FULL"] = "Allow only the full amount of order to be paid using internal account";
$MESS["SPOD_RESTRICT_CHANGE_PAYSYSTEM"] = "Orders in these statuses cannot change status";
$MESS["SPOD_NOT_CHOSEN"] = "(not selected)";
$MESS["SPOD_REFRESH_PRICE_AFTER_PAYSYSTEM_CHANGE"] = "Recalculate order when payment system status changes";
?>