<?
$MESS['SPOD_SALE_MODULE_NOT_INSTALL'] = "Модуль Интернет-магазин не установлен.";
$MESS['SPOD_CATALOG_MODULE_NOT_INSTALL'] = "Модуль Каталог товаров не установлен.";
$MESS['SPOD_ACCESS_DENIED'] = "Для просмотра заказа необходимо авторизоваться.";
$MESS['SPOD_TITLE'] = "Мой заказ №#ID#";
$MESS['SPOD_NO_ORDER'] = "Заказ №#ID# не найден.";
$MESS['SPOD_SALE_TAX_INPRICE'] = "включен в цену";
?>