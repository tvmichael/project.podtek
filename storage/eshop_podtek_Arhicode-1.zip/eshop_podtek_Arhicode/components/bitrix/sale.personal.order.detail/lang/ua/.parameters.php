<?
$MESS["SPOD_DISALLOW_CANCEL"] = "Заборонити скасування замовлення";
$MESS["SPOD_DESC_YES"] = "Так";
$MESS["SPOD_DESC_NO"] = "Ні";
$MESS["SPOD_PATH_TO_LIST"] = "Сторінка зі списком замовлень";
$MESS["SPOD_PATH_TO_CANCEL"] = "Сторінка скасування замовлення";
$MESS["SPOD_PATH_TO_PAYMENT"] = "Сторінка підключення платіжної системи";
$MESS["SPOD_ID"] = "Ідентифікатор замовлення";
$MESS["SPOD_PROPS_NOT_SHOW"] = "Не показувати властивості для типу платника";
$MESS["SPOD_SHOW_ALL"] = "(показувати всі)";
$MESS["SPOD_ACTIVE_DATE_FORMAT"] = "Формат показу дати";
$MESS["SPOD_CACHE_GROUPS"] = "Враховувати права доступу";
$MESS["SPOD_PARAM_PREVIEW_PICTURE_WIDTH"] = "Обмеження по ширині для анонсна зображення, px";
$MESS["SPOD_PARAM_PREVIEW_PICTURE_HEIGHT"] = "Обмеження по висоті для анонсна зображення, px";
$MESS["SPOD_PARAM_DETAIL_PICTURE_WIDTH"] = "Обмеження по ширині для детального зображення, px";
$MESS["SPOD_PARAM_DETAIL_PICTURE_HEIGHT"] = "Обмеження по висоті для детального зображення, px";
$MESS["SPOD_PARAM_CUSTOM_SELECT_PROPS"] = "Додаткові властивості інфоблоків";
$MESS["SPOD_PARAM_RESAMPLE_TYPE"] = "Тип масштабування";
$MESS["SPOD_PARAM_RESAMPLE_TYPE_BX_RESIZE_IMAGE_EXACT"] = "З обрізанням";
$MESS["SPOD_PARAM_RESAMPLE_TYPE_BX_RESIZE_IMAGE_PROPORTIONAL"] = "Із збереженням пропорцій";
$MESS["SPOD_PARAM_RESAMPLE_TYPE_BX_RESIZE_IMAGE_PROPORTIONAL_ALT"] = "Із збереженням пропорцій, поліпшена обробка";
$MESS["SPOD_PATH_TO_COPY"] = "Сторінка повторення замовлення";
$MESS["SPOD_ALLOW_INNER"] = "Дозволити оплату з внутрішнього рахунку";
$MESS["SPOD_ONLY_INNER_FULL"] = "Дозволити оплату з внутрішнього рахунку тільки в повному обсязі";
$MESS["SPOD_RESTRICT_CHANGE_PAYSYSTEM"] = "Заборонити зміну платіжної системи у замовлень в статусах";
$MESS["SPOD_NOT_CHOSEN"] = "(не обрано)";
$MESS["SPOD_REFRESH_PRICE_AFTER_PAYSYSTEM_CHANGE"] = "Перераховувати замовлення після зміни платіжної системи";
?>