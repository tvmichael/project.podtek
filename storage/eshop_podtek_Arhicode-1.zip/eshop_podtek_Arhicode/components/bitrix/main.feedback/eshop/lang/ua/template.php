<?
$MESS["MFT_CAPTCHA"] = "Захист від автоматичних повідомлень";
$MESS["MFT_MESSAGE"] = "Повідомлення";
$MESS["MFT_NAME"] = "Ваше ім'я";
$MESS["MFT_SUBMIT"] = "Надіслати";
$MESS["MFT_CAPTCHA_CODE"] = "Введіть слово на картинці";
$MESS["MFT_EMAIL"] = "Ваш E-mail";
?>