<?
$MESS["MFT_CAPTCHA"] = "CAPTCHA";
$MESS["MFT_MESSAGE"] = "Nachricht";
$MESS["MFT_NAME"] = "Name";
$MESS["MFT_SUBMIT"] = "Senden";
$MESS["MFT_CAPTCHA_CODE"] = "Geben Sie die Buchstaben ein, die Sie auf dem Bild sehen";
$MESS["MFT_EMAIL"] = "Ihre E-Mail-Adresse";
?>