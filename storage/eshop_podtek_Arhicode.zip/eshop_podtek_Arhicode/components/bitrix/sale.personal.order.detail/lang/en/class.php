<?
$MESS["SPOD_SALE_MODULE_NOT_INSTALL"] = "The e-Store module is not installed.";
$MESS["SPOD_CATALOG_MODULE_NOT_INSTALL"] = "The Commercial Catalog module is not installed.";
$MESS["SPOD_ACCESS_DENIED"] = "Please log in to view the order.";
$MESS["SPOD_TITLE"] = "My order ##ID#";
$MESS["SPOD_NO_ORDER"] = "Order ##ID# was not found.";
$MESS["SPOD_SALE_TAX_INPRICE"] = "included";
?>