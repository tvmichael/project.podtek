<?
$MESS ['SPOD_DEFAULT_TEMPLATE_NAME'] = "Order details page";
$MESS ['SPOD_DEFAULT_TEMPLATE_DESCRIPTION'] = "Displays Order detailed information";
$MESS ['SPOD_NAME'] = "Personal Section";
?>