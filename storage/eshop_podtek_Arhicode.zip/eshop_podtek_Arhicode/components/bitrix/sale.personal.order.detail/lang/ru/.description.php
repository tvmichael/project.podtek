<?
$MESS ['SPOD_DEFAULT_TEMPLATE_NAME'] = "Подробная информация о заказе";
$MESS ['SPOD_DEFAULT_TEMPLATE_DESCRIPTION'] = "Выводит подробную информацию по заказу";
$MESS ['SPOD_NAME'] = "Персональный раздел";
?>