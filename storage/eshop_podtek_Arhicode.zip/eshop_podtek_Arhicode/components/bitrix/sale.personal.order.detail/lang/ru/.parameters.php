<?
$MESS ['SPOD_DESC_YES'] = "Да";
$MESS ['SPOD_DESC_NO'] = "Нет";
$MESS ['SPOD_PATH_TO_LIST'] = "Страница со списком заказов";
$MESS ['SPOD_PATH_TO_CANCEL'] = "Страница отмены заказа";
$MESS ['SPOD_PATH_TO_PAYMENT'] = "Страница подключения платежной системы";
$MESS ['SPOD_ID'] = "Идентификатор заказа";
$MESS ['SPOD_ACTIVE_DATE_FORMAT'] = "Формат показа даты";

$MESS ['SPOD_PROPS_NOT_SHOW'] = "Не показывать свойства для типа плательщика";
$MESS ['SPOD_SHOW_ALL'] = "(показывать все)";
$MESS ['SPOD_CACHE_GROUPS'] = "Учитывать права доступа";

$MESS ['SPOD_PARAM_PREVIEW_PICTURE_WIDTH'] = "Ограничение по ширине для анонсного изображения, px";
$MESS ['SPOD_PARAM_PREVIEW_PICTURE_HEIGHT'] = "Ограничение по высоте для анонсного изображения, px";
$MESS ['SPOD_PARAM_DETAIL_PICTURE_WIDTH'] = "Ограничение по ширине для детального изображения, px";
$MESS ['SPOD_PARAM_DETAIL_PICTURE_HEIGHT'] = "Ограничение по высоте для детального изображения, px";
$MESS ['SPOD_PARAM_CUSTOM_SELECT_PROPS'] = "Дополнительные свойства инфоблока";

$MESS ['SPOD_PARAM_RESAMPLE_TYPE'] = "Тип масштабирования";
$MESS ['SPOD_PARAM_RESAMPLE_TYPE_BX_RESIZE_IMAGE_EXACT'] = "С обрезанием";
$MESS ['SPOD_PARAM_RESAMPLE_TYPE_BX_RESIZE_IMAGE_PROPORTIONAL'] = "С сохранением пропорций";
$MESS ['SPOD_PARAM_RESAMPLE_TYPE_BX_RESIZE_IMAGE_PROPORTIONAL_ALT'] = "С сохранением пропорций, улучшенная обработка";
$MESS ["SPOD_PATH_TO_COPY"] = "Страница повторения заказа";
$MESS ["SPOD_ALLOW_INNER"] = "Разрешить оплату с внутреннего счета";
$MESS ["SPOD_ONLY_INNER_FULL"] = "Разрешить оплату с внутреннего счета только в полном объеме";
$MESS ["SPOD_RESTRICT_CHANGE_PAYSYSTEM"] = "Запретить смену платежной системы у заказов в статусах";
$MESS ["SPOD_REFRESH_PRICE_AFTER_PAYSYSTEM_CHANGE"] = "Пересчитывать заказ после смены платежной системы";
$MESS ["SPOD_NOT_CHOSEN"] = "(не выбрано)";
$MESS ["SPOD_DISALLOW_CANCEL"] = "Запретить отмену заказа";
?>