<?
$MESS["SPOD_DISALLOW_CANCEL"] = "Stornierung der Bestellung nicht erlauben";
$MESS["SPOD_SHOW_ALL"] = "(alle anzeigen)";
$MESS["SPOD_ID"] = "Bestellungs ID";
$MESS["SPOD_PROPS_NOT_SHOW"] = "Eigenschaften für die Kundengruppe nicht anzeigen";
$MESS["SPOD_DESC_YES"] = "Ja";
$MESS["SPOD_DESC_NO"] = "Nein";
$MESS["SPOD_PATH_TO_PAYMENT"] = "Seite für die Integration des Zahlungssystems";
$MESS["SPOD_PATH_TO_LIST"] = "Seite mit Bestellungen";
$MESS["SPOD_PATH_TO_CANCEL"] = "Seite zum Stornieren einer Bestellung";
$MESS["SPOD_ACTIVE_DATE_FORMAT"] = "Datumformat";
$MESS["SPOD_CACHE_GROUPS"] = "Zugriffsrechte berücksichtigen";
$MESS["SPOD_PARAM_PREVIEW_PICTURE_WIDTH"] = "Maximale Breite des Vorschaubildes, px";
$MESS["SPOD_PARAM_PREVIEW_PICTURE_HEIGHT"] = "Maximale Höhe des Vorschaubildes, px";
$MESS["SPOD_PARAM_DETAIL_PICTURE_WIDTH"] = "Maximale Breite des detaillierten Bildes, px";
$MESS["SPOD_PARAM_DETAIL_PICTURE_HEIGHT"] = "Maximale Höhe des detaillierten Bildes, px";
$MESS["SPOD_PARAM_CUSTOM_SELECT_PROPS"] = "Zusätzliche Informationsblockeigenschaften";
$MESS["SPOD_PARAM_RESAMPLE_TYPE"] = "Bildskalierung";
$MESS["SPOD_PARAM_RESAMPLE_TYPE_BX_RESIZE_IMAGE_EXACT"] = "Abschneiden";
$MESS["SPOD_PARAM_RESAMPLE_TYPE_BX_RESIZE_IMAGE_PROPORTIONAL"] = "Verhältnisse beibehalten";
$MESS["SPOD_PARAM_RESAMPLE_TYPE_BX_RESIZE_IMAGE_PROPORTIONAL_ALT"] = "Verhältnisse beibehalten, verbesserte Qualität";
$MESS["SPOD_PATH_TO_COPY"] = "Seite zum Wiederholen der Bestellung";
$MESS["SPOD_ALLOW_INNER"] = "Zahlung über internes Konto aktivieren";
$MESS["SPOD_ONLY_INNER_FULL"] = "Nur kompletter Betrag der Bestellung darf über internes Konto bezahlt werden";
$MESS["SPOD_RESTRICT_CHANGE_PAYSYSTEM"] = "Status der Bestellungen in folgendem Status können nicht geändert werden";
$MESS["SPOD_NOT_CHOSEN"] = "(nicht ausgewählt)";
$MESS["SPOD_REFRESH_PRICE_AFTER_PAYSYSTEM_CHANGE"] = "Bestellung neu kalkulieren, wenn der Status des Zahlungssystems geändert wurde";
?>