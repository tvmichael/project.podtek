<?
$MESS["CT_BCF_FILTER_TITLE"] = "Фильтр";
$MESS["CT_BCF_SET_FILTER"] = "Показать";
$MESS["CT_BCF_DEL_FILTER"] = "Сбросить";
$MESS["CT_BCF_FROM"] = "от";
$MESS["CT_BCF_TO"] = "до";
?>