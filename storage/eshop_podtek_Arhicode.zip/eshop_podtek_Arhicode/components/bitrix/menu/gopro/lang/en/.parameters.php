<?
$MESS["RSGOPRO.SUB_TEMPLATE"] = "Menu style";
$MESS["RSGOPRO.SUB_TEMPLATE.horizontal1"] = "Horizontal menu";
$MESS["RSGOPRO.SUB_TEMPLATE.vertical1"] = "Vertical menu-lesenka";
$MESS["RSGOPRO.SUB_TEMPLATE.vertical2"] = "Vertical menu-shtorka";
$MESS["RSGOPRO_CATALOG_PATH"] = "The path to the root directory of the catalogue";
$MESS["RSGOPRO_MAX_ITEM"] = "Number of displayed items";
$MESS["RSGOPRO_IS_MAIN"] = "This is main page";
$MESS["RSGOPRO_PROPCODE_ELEMENT_IN_MENU"] = "Character code property to search for the goods on the menu";
?>