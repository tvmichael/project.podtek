<?
$MESS["MENU_THEME"] = "Тема меню";
$MESS["F_THEME_SITE"] = "Брать тему из настроек сайта (для решения bitrix.eshop)";
$MESS["F_THEME_BLUE"] = "Синяя";
$MESS["F_THEME_WOOD"] = "Дерево";
$MESS["F_THEME_YELLOW"] = "Желтая";
$MESS["F_THEME_GREEN"] = "Зеленая";
$MESS["F_THEME_RED"] = "Красная";
$MESS["F_THEME_BLACK"] = "Темная";
?>