<?
$MESS["CT_BCS_TPL_ELEMENT_DELETE_CONFIRM"] = "Alle mit diesem Eintrag verbundenen Informationen gehen verloren. Wollen Sie Fortfahren?";
$MESS["CT_BCS_TPL_MESS_BTN_BUY"] = "Kaufen";
$MESS["CT_BCS_TPL_MESS_BTN_ADD_TO_BASKET"] = "In Warenkorb";
$MESS["CT_BCS_TPL_MESS_PRODUCT_NOT_AVAILABLE"] = "nicht auf Lager";
$MESS["CT_BCS_TPL_MESS_BTN_DETAIL"] = "Mehr";
$MESS["CT_BCS_TPL_MESS_BTN_SUBSCRIBE"] = "Benachrichtigen wenn wieder auf Lager";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_BASKET_REDIRECT"] = "Zum Warenkorb";
$MESS["ADD_TO_BASKET_OK"] = "Produkt wurde zum Warenkorb hinzugefügt";
$MESS["CT_BCS_TPL_MESS_BTN_COMPARE"] = "Vergleichen";
$MESS["CT_BCS_CATALOG_TITLE_ERROR"] = "Fehler";
$MESS["CT_BCS_CATALOG_TITLE_BASKET_PROPS"] = "Elementeigenschaften, die zum Warenkorb hinzugefügt werden sollen";
$MESS["CT_BCS_CATALOG_BASKET_UNKNOWN_ERROR"] = "Unbekannter Fehler beim Hinzufügen eines Elementes zum Warenkorb";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_SEND_PROPS"] = "Auswählen";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_CLOSE"] = "Schließen";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_CLOSE_POPUP"] = "Weiter einkaufen";
$MESS["CT_BCS_CATALOG_MESS_COMPARE_OK"] = "Produkt wurde zur Vergleichsliste hinzugefügt";
$MESS["CT_BCS_CATALOG_MESS_COMPARE_TITLE"] = "Produktvergleich";
$MESS["CT_BCS_CATALOG_MESS_COMPARE_UNKNOWN_ERROR"] = "Fehler beim Hinzufügen des Produktes zur Vergleichsliste";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_COMPARE_REDIRECT"] = "Produkte vergleichen";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_LAZY_LOAD_WAITER"] = "Wird geladen";
$MESS["CT_BCS_CATALOG_PRICE_TOTAL_PREFIX"] = "Gesamt";
$MESS["CT_BCS_CATALOG_SHOW_MAX_QUANTITY"] = "Am Lager";
$MESS["CT_BCS_CATALOG_RELATIVE_QUANTITY_MANY"] = "Am Lager verfügbar";
$MESS["CT_BCS_CATALOG_RELATIVE_QUANTITY_FEW"] = "nur noch wenige";
$MESS["CT_BCS_CATALOG_MESS_BTN_LAZY_LOAD"] = "Mehr anzeigen";
?>