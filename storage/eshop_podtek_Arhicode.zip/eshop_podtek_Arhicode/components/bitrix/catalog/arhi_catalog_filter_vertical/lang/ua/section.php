<?
$MESS["CATALOG_PERSONAL_RECOM"] = "Персональні рекомендації";
?>