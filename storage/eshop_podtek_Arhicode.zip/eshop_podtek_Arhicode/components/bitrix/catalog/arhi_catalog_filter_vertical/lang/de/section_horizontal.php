<?
$MESS["CT_GIFTS_SECTION_LIST_BLOCK_TITLE_DEFAULT"] = "Geschenke für Produkte in diesem Katalog";
?>