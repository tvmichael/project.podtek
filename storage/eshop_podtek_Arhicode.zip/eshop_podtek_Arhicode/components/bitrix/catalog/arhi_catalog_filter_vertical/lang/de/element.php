<?
$MESS["CATALOG_PERSONAL_RECOM"] = "Persönliche Empfehlungen";
$MESS["CATALOG_POPULAR_IN_SECTION"] = "Beliebte Produkte";
$MESS["CATALOG_VIEWED"] = "Angezeigte Produkte";
$MESS["CATALOG_RECOMMENDED_BY_LINK"] = "Empfohlene Produkte";
?>