<?
$MESS["CATALOG_PERSONAL_RECOM"] = "Persönliche Empfehlungen";
?>