<?
$MESS["CT_GIFTS_SECTION_LIST_BLOCK_TITLE_DEFAULT"] = "Подарки к товарам этого раздела";

$MESS["CATALOG_SORT_LABEL"] = "Тип сортировки:";
$MESS["CATALOG_SORT_FIELD_SHOWS_ASC"] = "возростание популярности";
$MESS["CATALOG_SORT_FIELD_SHOWS_DESC"] = "убывание популярности";
$MESS["CATALOG_SORT_FIELD_PRICE_ASC"] = "возростание цены";
$MESS["CATALOG_SORT_FIELD_PRICE_DESC"] = "убывание цены";