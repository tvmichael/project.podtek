<?
$MESS["CATALOG_PERSONAL_RECOM"] = "Персональні рекомендації";
$MESS["CATALOG_POPULAR_IN_SECTION"] = "Популярні в розділі";
$MESS["CATALOG_VIEWED"] = "Переглядали";
$MESS["CATALOG_RECOMMENDED_BY_LINK"] = "З цим товаром рекомендуємо";
?>