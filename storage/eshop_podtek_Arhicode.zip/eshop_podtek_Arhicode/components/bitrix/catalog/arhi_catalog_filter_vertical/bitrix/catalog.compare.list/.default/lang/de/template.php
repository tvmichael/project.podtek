<?
$MESS["CATALOG_COMPARE_ELEMENTS"] = "Vergleichselemente";
$MESS["CATALOG_DELETE"] = "Löschen";
$MESS["CP_BCCL_TPL_MESS_COMPARE_COUNT"] = "Elemente in der Vergleichsliste:";
$MESS["CP_BCCL_TPL_MESS_COMPARE_PAGE"] = "Vergleichen";
?>