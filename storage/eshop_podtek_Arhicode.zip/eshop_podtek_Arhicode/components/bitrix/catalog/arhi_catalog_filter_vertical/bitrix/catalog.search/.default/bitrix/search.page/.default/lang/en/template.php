<?
$MESS["SEARCH_GO"] = "Go";
$MESS["CT_BSP_ADDITIONAL_PARAMS"] = "Additional search criteria";
$MESS["CT_BSP_KEYBOARD_WARNING"] = "Query input language changed for \"#query#\".";
?>