<?
$MESS["TP_CBIV_AVERAGE"] = "Середнє значення";
$MESS["TP_CBIV_RATING"] = "Рейтинг";
$MESS["TP_CBIV_DISPLAY_AS_RATING"] = "В якості рейтингу показувати";
?>