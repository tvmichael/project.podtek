<?
$MESS["CP_BCCL_TPL_PARAM_TITLE_POSITION_FIXED"] = "Відображати список порівняння поверх сторінки";
$MESS["CP_BCCL_TPL_PARAM_TITLE_POSITION"] = "Положення на сторінці";
$MESS["CP_BCCL_TPL_PARAM_POSITION_TOP_LEFT"] = "Угорі ліворуч";
$MESS["CP_BCCL_TPL_PARAM_POSITION_TOP_RIGHT"] = "Вгорі праворуч";
$MESS["CP_BCCL_TPL_PARAM_POSITION_BOTTOM_LEFT"] = "Внизу зліва";
$MESS["CP_BCCL_TPL_PARAM_POSITION_BOTTOM_RIGHT"] = "Внизу праворуч";
?>