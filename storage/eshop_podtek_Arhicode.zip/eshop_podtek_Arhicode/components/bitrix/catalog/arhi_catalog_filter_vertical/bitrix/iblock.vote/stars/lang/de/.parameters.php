<?
$MESS ['TP_CBIV_AVERAGE'] = "Durchschnittswert";
$MESS ['TP_CBIV_RATING'] = "Bewertung";
$MESS ['TP_CBIV_DISPLAY_AS_RATING'] = "Als Bewertung anzeigen";
?>