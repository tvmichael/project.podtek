<?
$MESS["CATALOG_COMPARE_ELEMENTS"] = "При зазначеній опції ціни будуть показані з урахуванням ПДВ.";
$MESS["CATALOG_DELETE"] = "Прибрати";
$MESS["CP_BCCL_TPL_MESS_COMPARE_COUNT"] = "Кількість елементів у списку порівняння:";
$MESS["CP_BCCL_TPL_MESS_COMPARE_PAGE"] = "Перейти на сторінку порівняння";
?>