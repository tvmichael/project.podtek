<?
$MESS["CPT_BCSL_VIEW_MODE_LINE"] = "Liste";
$MESS["CPT_BCSL_VIEW_MODE_TEXT"] = "Text";
$MESS["CPT_BCSL_VIEW_MODE_TILE"] = "Kacheln";
$MESS["CPT_BCSL_VIEW_MODE"] = "Ansichtsmodus der Unterbereiche";
$MESS["CPT_BCSL_SHOW_PARENT_NAME"] = "Bereichsnamen anzeigen";
$MESS["SHOW_PARENT_NAME_TIP"] = "Definiert, ob der Name des aktuellen Bereichs angezeigt wird (außer Root-Bereich).";
$MESS["CPT_BCSL_VIEW_MODE_LIST"] = "Mehrstufenliste ";
$MESS["CPT_BCSL_HIDE_SECTION_NAME"] = "Namen der Unterbereiche ausblenden";
$MESS["VIEW_MODE_TIP"] = "Bestimmt die Ansicht, in der Unterbereiche auf der Seite angezeigt werden. Wichtig: Nur die Option \"Mehrstufenliste\" kann eine beliebige Anzahl von Unterbereichen bestimmen. Für alle anderen Ansichtsmodi muss als die Verschachtelungstiefe 1 angegeben werden.";
$MESS["HIDE_SECTION_NAME_TIP"] = "Wenn der Ansichtsmodus \"Kacheln\" ausgewählt wurde, werden nur die Bilder der Bereiche angezeigt.";
?>