<?
$MESS["CP_BCCL_TPL_PARAM_TITLE_POSITION_FIXED"] = "Vergleichstabelle schwebend über der Seite anzeigen";
$MESS["CP_BCCL_TPL_PARAM_TITLE_POSITION"] = "Position";
$MESS["CP_BCCL_TPL_PARAM_POSITION_TOP_LEFT"] = "oben links";
$MESS["CP_BCCL_TPL_PARAM_POSITION_TOP_RIGHT"] = "oben rechts";
$MESS["CP_BCCL_TPL_PARAM_POSITION_BOTTOM_LEFT"] = "unten links";
$MESS["CP_BCCL_TPL_PARAM_POSITION_BOTTOM_RIGHT"] = "unten rechts";
?>