<?
$MESS["USER_PROPERTY_NAME"] = "Name der Registerkarte mit zusдtzlichen Eigenschaften";
?>