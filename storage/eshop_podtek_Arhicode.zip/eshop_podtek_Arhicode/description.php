<?
$arTemplate = array (
  'NAME' => 'Адаптивный шаблон podtek : Arhicode',
  'DESCRIPTION' => 'Адаптивный шаблон podtek : Arhicode',
  'SORT' => '',
  'TYPE' => '',
  'EDITOR_STYLES' => 
  array (
    0 => '/bitrix/css/main/bootstrap.css',
    1 => '/bitrix/css/main/font-awesome.css',
  ),
);
?>