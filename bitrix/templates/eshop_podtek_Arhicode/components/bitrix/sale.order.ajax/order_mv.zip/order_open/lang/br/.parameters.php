<?
$MESS["T_IMG_WIDTH"] = "Largura do produto na  imagem ";
$MESS["T_IMG_HEIGHT"] = "Altura do produto na imagem";
$MESS["T_PAYMENT_SERVICES_NAMES"] = "Mostrar nomes do Sistema de pagamento";
$MESS["T_ALLOW_NEW_PROFILE"] = "Permitir vários perfis de clientes ";
$MESS["T_SHOW_STORES_IMAGES"] = "Mostrar imagens no armazénamento de  forma pick-up de seleção de ponto ";
?>